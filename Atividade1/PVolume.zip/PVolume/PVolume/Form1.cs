﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
        
    {
        Double raio, altura, volume;

        private void textAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(textAltura.Text, out altura)
                || (altura <= 0))
            {
                MessageBox.Show("Altura inválida");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            textAltura.Text = "";
            textRaio.Text = string.Empty;
            textVolume.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textRaio.Text, out raio)
                || (raio <= 0)) 
            {
                MessageBox.Show("Raio Inválido");
                textRaio.Focus();
            }
            else if(!Double.TryParse(textAltura.Text, out altura)
                ||(altura <= 0))
            {
                MessageBox.Show("Altura inválida");
                textAltura.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                textVolume.Text= volume.ToString("N2");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textRaio.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio inválido");
            }
            /* else if (raio<=0)
             
                MessageBox.Show("Raio deve ser maior que zero");

             */
        }
    }
}
