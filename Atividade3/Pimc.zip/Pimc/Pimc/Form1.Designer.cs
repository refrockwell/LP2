﻿namespace Pimc
{
    partial class Pimc
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.mtxtPeso = new System.Windows.Forms.MaskedTextBox();
            this.mtxtAltura = new System.Windows.Forms.MaskedTextBox();
            this.mtxtIMC = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(503, 332);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 23);
            this.btnSair.TabIndex = 0;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(403, 332);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(265, 332);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(115, 23);
            this.btnCalc.TabIndex = 2;
            this.btnCalc.Text = "CALCULAR";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(299, 145);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(72, 16);
            this.lbl1.TabIndex = 6;
            this.lbl1.Text = "Peso Atual";
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(299, 202);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(41, 16);
            this.lbl2.TabIndex = 7;
            this.lbl2.Text = "Altura";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(299, 265);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(30, 16);
            this.lbl3.TabIndex = 8;
            this.lbl3.Text = "IMC";
            // 
            // mtxtPeso
            // 
            this.mtxtPeso.Location = new System.Drawing.Point(403, 139);
            this.mtxtPeso.Name = "mtxtPeso";
            this.mtxtPeso.Size = new System.Drawing.Size(100, 22);
            this.mtxtPeso.TabIndex = 9;
            this.mtxtPeso.Validated += new System.EventHandler(this.mtxtPeso_Validated);
            // 
            // mtxtAltura
            // 
            this.mtxtAltura.Location = new System.Drawing.Point(403, 202);
            this.mtxtAltura.Name = "mtxtAltura";
            this.mtxtAltura.Size = new System.Drawing.Size(100, 22);
            this.mtxtAltura.TabIndex = 10;
            this.mtxtAltura.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtxtAltura_MaskInputRejected);
            this.mtxtAltura.Validated += new System.EventHandler(this.mtxtAltura_Validated);
            // 
            // mtxtIMC
            // 
            this.mtxtIMC.Location = new System.Drawing.Point(403, 259);
            this.mtxtIMC.Name = "mtxtIMC";
            this.mtxtIMC.Size = new System.Drawing.Size(100, 22);
            this.mtxtIMC.TabIndex = 11;
            this.mtxtIMC.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mtxtIMC_MaskInputRejected);
            // 
            // Pimc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 516);
            this.Controls.Add(this.mtxtIMC);
            this.Controls.Add(this.mtxtAltura);
            this.Controls.Add(this.mtxtPeso);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSair);
            this.Name = "Pimc";
            this.Text = "Pimc";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.MaskedTextBox mtxtPeso;
        private System.Windows.Forms.MaskedTextBox mtxtAltura;
        private System.Windows.Forms.MaskedTextBox mtxtIMC;
    }
}

