﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Pimc : Form 
    {
        double peso, altura, resultado;
        public Pimc()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mtxtAltura.Clear();
            mtxtPeso.Clear();
            mtxtIMC.Clear();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            resultado = peso / Math.Pow(altura, 2);
            resultado = Math.Round(resultado, 1);
            mtxtIMC.Text = resultado.ToString();

        }

        private void mtxtPeso_Validated(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mtxtPeso.Text);
            }
            catch {
                mtxtPeso.Focus();
            }   
        }

        private void mtxtAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void mtxtAltura_Validated(object sender, EventArgs e)
        {
            try
            {
                altura = Convert.ToDouble(mtxtAltura.Text);
            }
            catch
            {
                mtxtAltura.Focus(); 
            }
        }

        private void mtxtIMC_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }
    }
}
