﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;


namespace PContato0030482513031
{
    class Cidade
    { //atributos
        private int idcidade;
        private string nomecidade;
        private string ufcidade;

        //propriedades

        public int idCidade
        {
            get
            {
                return idCidade;
            }
            set
            {
                idCidade = value;
            }
        }
             public string nomeCidade
        {
            get
            {
                return nomeCidade;
            }
            set
            {
                nomeCidade = value;
            }

        }
        public string ufCidade
        {
            get
            {
                return ufCidade;
            }
            set
            {
                ufCidade = value;
            }

        }

        public DataTable Listar()
        {
            SqlDataAdapter daCidade;

            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE",
                FrmPrincipal.conexao);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }
            catch (Exception) 
            {
                throw;
            }  
            return dtCidade; 
        }
    }
}
