﻿namespace PMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_remover = new Button();
            lbl_Numero2 = new Label();
            lbl_Numero1 = new Label();
            txtNumero2 = new TextBox();
            txtNumero1 = new TextBox();
            SuspendLayout();
            // 
            // btn_remover
            // 
            btn_remover.Font = new Font("Segoe UI", 22F);
            btn_remover.Location = new Point(589, 335);
            btn_remover.Margin = new Padding(2);
            btn_remover.Name = "btn_remover";
            btn_remover.Size = new Size(282, 114);
            btn_remover.TabIndex = 17;
            btn_remover.Text = "Realizar sorteio";
            btn_remover.UseVisualStyleBackColor = true;
            btn_remover.Click += btn_remover_Click;
            // 
            // lbl_Numero2
            // 
            lbl_Numero2.AutoSize = true;
            lbl_Numero2.Font = new Font("Segoe UI", 22F);
            lbl_Numero2.Location = new Point(448, 235);
            lbl_Numero2.Margin = new Padding(2, 0, 2, 0);
            lbl_Numero2.Name = "lbl_Numero2";
            lbl_Numero2.Size = new Size(187, 50);
            lbl_Numero2.TabIndex = 16;
            lbl_Numero2.Text = "Numero 2";
            // 
            // lbl_Numero1
            // 
            lbl_Numero1.AutoSize = true;
            lbl_Numero1.Font = new Font("Segoe UI", 22F);
            lbl_Numero1.Location = new Point(448, 160);
            lbl_Numero1.Margin = new Padding(2, 0, 2, 0);
            lbl_Numero1.Name = "lbl_Numero1";
            lbl_Numero1.Size = new Size(187, 50);
            lbl_Numero1.TabIndex = 15;
            lbl_Numero1.Text = "Numero 1";
            // 
            // txtNumero2
            // 
            txtNumero2.Font = new Font("Segoe UI", 22F);
            txtNumero2.Location = new Point(635, 233);
            txtNumero2.Margin = new Padding(2);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(323, 56);
            txtNumero2.TabIndex = 14;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtNumero1
            // 
            txtNumero1.Font = new Font("Segoe UI", 22F);
            txtNumero1.Location = new Point(635, 158);
            txtNumero1.Margin = new Padding(2);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(323, 56);
            txtNumero1.TabIndex = 13;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1437, 721);
            Controls.Add(btn_remover);
            Controls.Add(lbl_Numero2);
            Controls.Add(lbl_Numero1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            Load += frmExercicio5_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_remover;
        private Label lbl_Numero2;
        private Label lbl_Numero1;
        private TextBox txtNumero2;
        private TextBox txtNumero1;
    }
}