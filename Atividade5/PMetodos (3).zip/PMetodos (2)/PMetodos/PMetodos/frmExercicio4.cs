﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btn_ContaNum_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int contNumero = 0;

            while (cont < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[cont]))
                    contNumero++;
                cont++;
            }

            MessageBox.Show($"O texto tem {contNumero} números");
        }

        private void btn_posbranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter branco é: {i + 1}");
                    break;
                }
            }
        }

        private void btn_ContaLet_Click(object sender, EventArgs e)
        {
            int contLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contLetra++;
                }
            }

            MessageBox.Show($"o texto tem {contLetra} letras");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmExercicio4_Load(object sender, EventArgs e)
        {

        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_ContaNum_Click_1(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador]))
                    contaNum++;
                contador++;
            }

            MessageBox.Show($"O texto tem {contaNum} números");
        }


        private void btn_ContaLetras_Click(object sender, EventArgs e)
        {
            int contLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contLetra} letras");
        }

        private void btn_PosBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show($"A posição do 1º caracter branco é: {i + 1}");
                    break;
                } else if(i ==  rchtxtFrase.Text.Length - 1 && !Char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    MessageBox.Show("Não contém espaços");
                }
            }
        }
    }
}
