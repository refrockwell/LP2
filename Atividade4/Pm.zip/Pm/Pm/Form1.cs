﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pm
{
    public partial class Form1 : Form
    {
        Double ladoA, ladoB, ladoC;

        public Form1()
        { 

            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtLadoB_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtLadoB, "");
                ladoB = Convert.ToDouble(txtLadoB.Text);
            }
            catch
            {
                errorProvider1.SetError(txtLadoB, "Número Inválido");
                txtLadoB.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtLadoC, "");
                ladoC = Convert.ToDouble(txtLadoC.Text);
            }
            catch
            {
                errorProvider1.SetError(txtLadoC, "Número Inválido");
                txtLadoC.Focus();
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            if (ladoA + ladoB > ladoC &&
                ladoA + ladoC > ladoB &&
                ladoB + ladoC > ladoA)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    MessageBox.Show("Equilátero");
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    MessageBox.Show("Isóceles");
                }
                else
                {
                    MessageBox.Show("Escaleno"); 
                }
            }
            else
            {
                MessageBox.Show("Os valores não formam um triângulo!!!");
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            {
                txtLadoA.Clear();
                txtLadoB.Clear();
                txtLadoC.Clear();
                errorProvider1.Clear();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtLadoA, "");
                ladoA= Convert.ToDouble(txtLadoA.Text);
            }
            catch
            {
                errorProvider1.SetError(txtLadoA, "Número Inválido");
                txtLadoA.Focus();
            }
        }
    }
}
