﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i <= 19; i++) 
            {
                auxiliar = Interaction.InputBox("Digite um número", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                    i--;
                }

            }
            Array.Reverse(vetor);

            auxiliar = String.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            int num_alunos = 2;
            double[,] notas = new double[num_alunos, 3];
            string auxiliar = "";
            for (int i = 0; i < num_alunos; i++)
            {   
                for(int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota do aluno", "Entrada de Dados");
                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i,j]<0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida");
                            j-- ;
                    }
                        
                }
            }

            double media;
            string saida="";
            for(int i = 0; i <num_alunos; i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2])/3;
                saida += "Aluno " + (i + 1) + " Média " + media.ToString("n2")+"\n";
            }
            MessageBox.Show(saida);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx4>().Count() > 0) 
            {
                Application.OpenForms["FrmEx4"].BringToFront();
            }
            else
            {
                FrmEx4 obj4 = new FrmEx4();
                obj4.Show();
            }
            
        
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx5>().Count() > 0)
            {
                Application.OpenForms["FrmEx5"].BringToFront();
            }
            else
            {
                FrmEx5 obj5 = new FrmEx5();
                obj5.Show();
            }
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList listaDeAlunos = new ArrayList();

           
            listaDeAlunos.Add("Ana");
            listaDeAlunos.Add("André");
            listaDeAlunos.Add("Beatriz");
            listaDeAlunos.Add("Camila");
            listaDeAlunos.Add("João");
            listaDeAlunos.Add("Joana");
            listaDeAlunos.Add("Otávio");
            listaDeAlunos.Add("Marcelo");
            listaDeAlunos.Add("Pedro");
            listaDeAlunos.Add("Thais");

            // 2. Exclua o aluno Otávio do ArrayList
            listaDeAlunos.Remove("Otávio");

            // 3. Imprima os demais construindo uma string para a MessageBox
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Lista de Alunos (Otávio Excluído):\n");

            foreach (string aluno in listaDeAlunos)

            MessageBox.Show(sb.ToString(), "Resultado do exercício", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
