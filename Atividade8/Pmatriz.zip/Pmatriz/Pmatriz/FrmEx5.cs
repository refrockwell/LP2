﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq; // Necessário para o método .Contains() na validação
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// ** A REFERÊNCIA Microsoft.VisualBasic DEVE ESTAR ADICIONADA AO PROJETO **
// Se você quiser usar o using Microsoft.VisualBasic, pode adicioná-lo, 
// mas não é estritamente necessário se usar o nome completo Microsoft.VisualBasic.Interaction.InputBox

namespace Pmatriz
{
    public partial class FrmEx5 : Form
    {
        // Variáveis de escopo do formulário
        private int numeroAlunosN;
        private const int NUMERO_QUESTOES = 10;

        // 1. Vetor gabarito (já com dados)
        private readonly char[] gabarito = { 'A', 'C', 'B', 'D', 'E', 'B', 'C', 'A', 'D', 'B' };

        // Matriz N x 10 para armazenar as respostas dos alunos
        private char[,] respostasAlunos;


        public FrmEx5()
        {
            InitializeComponent();
            // Inicia o cálculo do número de alunos e a matriz
            CalcularNumeroDeAlunos();
        }

        // Método de clique do botão "Verificar"
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            // Limpa o ListBox. Assume que o nome do controle é 'listBoxResultado'
            listBoxResultado.Items.Clear();

            // Desativa o botão para evitar cliques múltiplos
            btnVerificar.Enabled = false;

            // Chama o método para receber as respostas via InputBox
            if (!ReceberRespostasAlunos())
            {
                // Se o usuário cancelou a entrada, reativa e sai
                btnVerificar.Enabled = true;
                return;
            }

            // Compara as respostas e exibe o resultado
            CompararERegistrarResultados();

            // Reativa o botão
            btnVerificar.Enabled = true;
        }

        private void CalcularNumeroDeAlunos()
        {
            // Pede o último dígito do RA via InputBox
            string inputRA = Microsoft.VisualBasic.Interaction.InputBox(
                "Digite o último dígito do seu RA para calcular 'N' (alunos):",
                "Cálculo de N",
                "1"
            );

            if (int.TryParse(inputRA, out int ultimoDigitoRA))
            {
                // Lógica: Se 0, N=2. Senão, N = último dígito + 1.
                numeroAlunosN = (ultimoDigitoRA == 0) ? 2 : ultimoDigitoRA + 1;
            }
            else
            {
                MessageBox.Show("Dígito inválido. Usando N=3 como padrão.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                numeroAlunosN = 3;
            }

            // Inicializa a matriz com N calculado
            respostasAlunos = new char[numeroAlunosN, NUMERO_QUESTOES];
        }

        private bool ReceberRespostasAlunos()
        {
            for (int i = 0; i < numeroAlunosN; i++) // Itera sobre os alunos
            {
                for (int j = 0; j < NUMERO_QUESTOES; j++) // Itera sobre as questões
                {
                    string inputResposta;
                    char respostaChar = ' ';
                    bool respostaValida = false;

                    while (!respostaValida)
                    {
                        // Recebe a resposta e converte para maiúscula
                        inputResposta = Microsoft.VisualBasic.Interaction.InputBox(
                            $"Aluno {i + 1}, Questão {j + 1} (Gabarito: {gabarito[j]}):\n\nDigite sua resposta (A, B, C, D ou E):",
                            "Entrada de Respostas",
                            ""
                        ).ToUpper();

                        // Captura o cancelamento (somente na primeira questão do aluno)
                        if (string.IsNullOrEmpty(inputResposta) && j == 0)
                        {
                            MessageBox.Show("Entrada de respostas cancelada.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return false;
                        }

                        // Validação: A, B, C, D ou E (maiúsculas) e apenas 1 caractere
                        if (inputResposta.Length == 1 && "ABCDE".Contains(inputResposta))
                        {
                            respostaChar = inputResposta[0];
                            respostaValida = true;
                        }
                        else if (!string.IsNullOrEmpty(inputResposta))
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.", "Erro de Entrada", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    // Armazena a resposta válida
                    respostasAlunos[i, j] = respostaChar;
                }
            }
            return true;
        }

        private void CompararERegistrarResultados()
        {
            string resultadoLinha;

            for (int i = 0; i < numeroAlunosN; i++) // Alunos
            {
                for (int j = 0; j < NUMERO_QUESTOES; j++) // Questões
                {
                    char respostaAluno = respostasAlunos[i, j];
                    char respostaCorreta = gabarito[j];

                    if (respostaAluno == respostaCorreta)
                    {
                        // Formato da saída quando acerta
                        resultadoLinha = $"O aluno {i + 1} acertou questão:{j + 1} era {respostaCorreta} escolheu {respostaAluno}";
                    }
                    else
                    {
                        // Formato da saída quando erra
                        resultadoLinha = $"O aluno {i + 1} errou questão:{j + 1} era {respostaCorreta} escolheu {respostaAluno}";
                    }

                    // Adiciona ao ListBox
                    listBoxResultado.Items.Add(resultadoLinha);
                }
            }
        }

        // Método FrmEx5_Load pode ser deixado vazio ou removido, pois 
        // a inicialização já acontece no construtor FrmEx5().
        private void FrmEx5_Load(object sender, EventArgs e)
        {
            // Vazio
        }
    }
}

