﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class FrmEx4 : Form
    {
        public FrmEx4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetor1=new string[10];
            int[] vetor2= new int[10];

            string auxiliar="";
            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1} nome", "Entrada de dados");
                if (auxiliar == "" || auxiliar.Replace(" ","").Length==0)
                {
                    MessageBox.Show("Nome Inválido");
                    i--;
                }
                else
                {
                    vetor1[i] = auxiliar;
                    vetor2[i] = auxiliar.Replace(" ", "").Length;
                }
            }
            for (int i = 0;i < 10; i++) 
            {
                lstbxNomes.Items.Add("O nome:" + vetor1[i]+" tem" + vetor2[i]+"caracteres" );
            }
        }
    }
}
